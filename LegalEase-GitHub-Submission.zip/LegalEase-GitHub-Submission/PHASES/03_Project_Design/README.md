# Phase 3 - Project Design

## Architecture

```text
User
  |
  v
Streamlit Frontend
  |
  | HTTP JSON
  v
FastAPI Backend
  |
  +--> Gemini Generator
  |
  +--> Mock Generator
  |
  v
Generated Document
  |
  +--> Editable Preview
  +--> TXT Export
  +--> DOCX Export
  +--> PDF Export
```

## Main Modules
- `frontend/app.py` - Streamlit user interface
- `backend/main.py` - FastAPI application
- `backend/routes.py` - generation and metadata routes
- `backend/schemas.py` - request/response validation
- `backend/config.py` - environment configuration
- `ai_core/gemini_generator.py` - Gemini integration
- `ai_core/mock_generator.py` - deterministic development generator
- `services/document_service.py` - HTML, DOCX, and PDF formatting
- `tests/` - automated tests

## Data Flow
1. User enters document details.
2. Frontend sends a JSON request to `/generate`.
3. Backend validates the request.
4. Selected generator creates the draft.
5. Backend returns document text and metadata.
6. Frontend displays and allows editing.
7. User downloads the desired output format.
