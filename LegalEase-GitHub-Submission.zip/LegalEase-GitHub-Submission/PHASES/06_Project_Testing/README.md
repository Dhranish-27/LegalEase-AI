# Phase 6 - Project Testing

## Test Areas
- FastAPI root endpoint
- Health endpoint
- Document generation endpoint
- Request validation
- Text sanitization
- HTML preview formatting
- DOCX generation
- PDF generation

## Test Command

```powershell
pytest -q
```

## Expected Result
The supplied project test suite is designed to report all tests passing in the configured mock-mode development environment.

## Manual Test Checklist
- [ ] Backend starts without errors.
- [ ] `/health` returns status `ok`.
- [ ] `/docs` opens FastAPI Swagger documentation.
- [ ] Frontend opens in Streamlit.
- [ ] Required fields are validated.
- [ ] A mock document can be generated.
- [ ] Generated text can be edited.
- [ ] TXT download works.
- [ ] DOCX download works.
- [ ] PDF download works.
- [ ] Gemini mode works when a valid API key is configured.
