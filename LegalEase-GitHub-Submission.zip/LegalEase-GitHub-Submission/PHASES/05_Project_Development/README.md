# Phase 5 - Project Development

## Implemented Components
- Streamlit frontend
- FastAPI backend
- Gemini document generator
- Mock document generator
- Environment configuration
- Request/response validation
- DOCX export
- PDF export
- TXT export through Streamlit download
- HTML preview formatting helper
- Automated tests
- Docker and Docker Compose configuration

## Run Locally

```powershell
py -3.12 -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

For the first run, keep `MOCK_MODE=true` in `.env`.

Backend:

```powershell
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Frontend, in a second terminal:

```powershell
streamlit run frontend/app.py
```

Open `http://localhost:8501`.

To use Gemini, set `MOCK_MODE=false` and provide `GEMINI_API_KEY` in `.env`.
