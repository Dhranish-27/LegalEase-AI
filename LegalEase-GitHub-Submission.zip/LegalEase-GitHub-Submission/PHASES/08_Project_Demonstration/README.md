# Phase 8 - Project Demonstration

## Suggested Demonstration Flow
1. Open the LegalEase project in VS Code.
2. Start the FastAPI backend.
3. Start the Streamlit frontend.
4. Show the input form.
5. Enter a sample document type, parties, date, and terms.
6. Generate the document in mock mode.
7. Show the editable preview.
8. Modify a clause in the editor.
9. Download TXT, DOCX, and PDF.
10. Open the FastAPI Swagger page and show `/health` and `/generate`.
11. Show the automated test result using `pytest -q`.
12. If an API key is available, demonstrate Gemini mode separately.

## Suggested Demo Evidence
- Screenshot of the input page
- Screenshot of generated document preview
- Screenshot of DOCX/PDF output
- Screenshot of Swagger API documentation
- Screenshot of passing tests
- Optional short demo video

## Presentation Points
Explain the problem, architecture, AI integration, document-generation workflow, testing approach, and limitations. Emphasize that the system produces drafts and is not a replacement for professional legal advice.
