from datetime import date
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator

class DocumentRequest(BaseModel):
    document_type: str = Field(min_length=2, max_length=120)
    parties: str = Field(min_length=2, max_length=5000)
    terms: List[str] = Field(min_length=1, max_length=40)
    effective_date: str = Field(min_length=2, max_length=100)
    additional_instructions: Optional[str] = Field(default='', max_length=6000)

    @field_validator('document_type', 'parties', 'effective_date', 'additional_instructions', mode='before')
    @classmethod
    def clean_strings(cls, value):
        return value.strip() if isinstance(value, str) else value

    @field_validator('terms', mode='before')
    @classmethod
    def clean_terms(cls, value):
        if isinstance(value, str):
            value = [item.strip() for item in value.split(';')]
        if not isinstance(value, list):
            raise ValueError('terms must be a list or semicolon-separated string')
        cleaned = [str(item).strip() for item in value if str(item).strip()]
        if not cleaned:
            raise ValueError('At least one term is required')
        return cleaned

class DocumentResponse(BaseModel):
    success: bool = True
    document_type: str
    content: str
    disclaimer: str
    model: str
    mock_mode: bool

class ErrorResponse(BaseModel):
    detail: str
