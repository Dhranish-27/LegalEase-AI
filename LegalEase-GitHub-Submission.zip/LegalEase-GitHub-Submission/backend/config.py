from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = 'LegalEase'
    app_version: str = '1.0.0'
    environment: str = 'development'
    gemini_api_key: str = ''
    gemini_model: str = 'gemini-2.5-flash'
    mock_mode: bool = True
    frontend_origin: str = 'http://localhost:8501'
    max_terms: int = 40
    max_input_chars: int = 20000
    model_timeout_seconds: int = 90
    model_temperature: float = 0.25
    model_max_output_tokens: int = 8192
    model_thinking_budget: int = 0
    model_retry_count: int = 2
    disclaimer: str = ('LegalEase generates AI-assisted draft documents for informational purposes. '
                       'They are not a substitute for advice from a qualified lawyer and should be reviewed before use.')
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore', case_sensitive=False)

@lru_cache
def get_settings() -> Settings:
    return Settings()
