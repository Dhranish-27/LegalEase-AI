from __future__ import annotations

import re
from typing import Iterable

from backend.config import Settings

class GeminiGenerationError(RuntimeError):
    pass

class GeminiDocumentGenerator:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._client = None

    def _get_client(self):
        if self._client is not None:
            return self._client
        if not self.settings.gemini_api_key:
            raise GeminiGenerationError('GEMINI_API_KEY is not configured.')
        try:
            from google import genai
        except ImportError as exc:
            raise GeminiGenerationError('google-genai is not installed. Run: pip install -r requirements.txt') from exc
        self._client = genai.Client(api_key=self.settings.gemini_api_key)
        return self._client

    @staticmethod
    def _terms_text(terms: Iterable[str]) -> str:
        return '\n'.join(f'{i}. {term}' for i, term in enumerate(terms, 1))

    def build_prompt(self, document_type: str, parties: str, terms: list[str], effective_date: str, additional_instructions: str = '') -> str:
        return f'''You are an expert legal-document drafting assistant. Draft a professional, editable {document_type} from the supplied facts.

IMPORTANT:
- Treat every supplied fact as user-provided input; do not invent names, addresses, amounts, dates, obligations, governing law, or signatures.
- If an essential fact is missing, use a clear placeholder such as [INSERT GOVERNING LAW] rather than fabricating it.
- Use neutral, professional legal language and clear section headings.
- Preserve all requested terms and dates accurately.
- Produce a draft only; do not claim that it is legally valid, jurisdiction-specific, or attorney-reviewed.
- Include signature blocks appropriate to the parties.
- Do not include markdown code fences.

DOCUMENT TYPE: {document_type}
PARTIES: {parties}
EFFECTIVE DATE: {effective_date}
REQUESTED TERMS:
{self._terms_text(terms)}
ADDITIONAL INSTRUCTIONS:
{additional_instructions or 'None'}

Return only the document text.'''

    def generate_document(self, document_type: str, parties: str, terms: list[str], effective_date: str, additional_instructions: str = '') -> str:
        prompt = self.build_prompt(document_type, parties, terms, effective_date, additional_instructions)
        client = self._get_client()
        try:
            from google.genai import types
            response = client.models.generate_content(
                model=self.settings.gemini_model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=self.settings.model_temperature,
                    max_output_tokens=self.settings.model_max_output_tokens,
                    thinking_config=types.ThinkingConfig(thinking_budget=self.settings.model_thinking_budget),
                ),
            )
            text = (response.text or '').strip()
        except Exception as exc:
            raise GeminiGenerationError(f'Gemini generation failed: {exc}') from exc
        text = re.sub(r'^```(?:text|markdown)?\s*|\s*```$', '', text, flags=re.IGNORECASE).strip()
        if len(text) < 80:
            raise GeminiGenerationError('Gemini returned an unexpectedly short document.')
        return text
