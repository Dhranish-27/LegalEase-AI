# LegalEase - GitHub Submission Structure

```text
LegalEase/
├── PHASES/
│   ├── 01_Brainstorming_and_Ideation/
│   ├── 02_Requirement_Analysis/
│   ├── 03_Project_Design/
│   ├── 04_Project_Planning/
│   ├── 05_Project_Development/
│   ├── 06_Project_Testing/
│   ├── 07_Project_Documentation/
│   └── 08_Project_Demonstration/
├── ai_core/
├── backend/
├── frontend/
├── services/
├── assets/
├── tests/
├── .streamlit/
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── requirements.txt
├── README.md
└── GITHUB_SUBMISSION_STRUCTURE.md
```

All eight required phases are represented as separate folders. The application source code remains in its functional modules so it can be run directly from the repository root.
