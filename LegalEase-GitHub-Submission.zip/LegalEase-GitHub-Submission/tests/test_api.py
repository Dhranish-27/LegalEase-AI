from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_root():
    r = client.get('/')
    assert r.status_code == 200
    assert r.json()['status'] == 'running'

def test_health():
    r = client.get('/health')
    assert r.status_code == 200

def test_generate_mock():
    r = client.post('/generate', json={'document_type':'NDA','parties':'A (Discloser), B (Recipient)','terms':['Confidentiality for 2 years','No disclosure to third parties'],'effective_date':'2026-09-30'})
    assert r.status_code == 200
    data = r.json()
    assert data['success'] is True
    assert 'Confidentiality' in data['content']

def test_generate_validation():
    r = client.post('/generate', json={'document_type':'NDA','parties':'','terms':[],'effective_date':''})
    assert r.status_code == 422
