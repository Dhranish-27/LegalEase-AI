# LegalEase — AI-Powered Legal Document Generator

LegalEase implements the supplied project specification: Streamlit frontend, FastAPI backend, Gemini-powered drafting, editable preview, and TXT/DOCX/PDF exports with branding.

> **Legal notice:** This is an AI-assisted drafting application, not a law firm or legal adviser. Generated text may contain errors or jurisdictional omissions. Review documents with a qualified legal professional before signing or relying on them.

## Architecture

```text
Streamlit (frontend/app.py)
        |
        | POST /generate
        v
FastAPI (backend/main.py + routes.py)
        |
        v
GeminiDocumentGenerator (ai_core/gemini_generator.py)
        |
        v
Google Gemini API

Generated text -> Streamlit editable preview -> TXT / DOCX / PDF
```

The source document selected Gemini 1.5 Pro and the legacy `google-generativeai` package. Those choices are retained as the documented architecture, but the implementation uses Google's current `google-genai` SDK and a configurable current model so the application is maintainable.

## Requirements

- Python 3.10+ (3.12 recommended)
- VS Code
- Internet access for package installation and Gemini calls
- Gemini API key for real AI mode

## VS Code setup — Windows

Open this folder in VS Code.

### 1. Create a virtual environment

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 2. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Create `.env`

Copy `.env.example` to `.env`.

For an initial end-to-end test without an API key:

```env
MOCK_MODE=true
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
BACKEND_URL=http://127.0.0.1:8000
FRONTEND_ORIGIN=http://localhost:8501
```

For real Gemini generation:

```env
MOCK_MODE=false
GEMINI_API_KEY=YOUR_GEMINI_API_KEY
GEMINI_MODEL=gemini-2.5-flash
BACKEND_URL=http://127.0.0.1:8000
FRONTEND_ORIGIN=http://localhost:8501
```

### 4. Start the backend

Terminal 1:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Backend:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/health

### 5. Start Streamlit

Terminal 2:

```powershell
.\.venv\Scripts\Activate.ps1
streamlit run frontend/app.py
```

Frontend:

- http://localhost:8501

## Test the application

### Automated tests

```powershell
pytest -q
```

The test suite verifies:

- FastAPI root and health endpoints
- `/generate` request validation
- Mock document generation
- Text sanitization
- HTML preview generation
- DOCX creation
- PDF creation

### Manual test

Enter:

**Document type**

`Freelance Work Contract`

**Parties**

`Jane Doe (Service Provider), TechNova Inc. (Client)`

**Effective date**

`April 10, 2025`

**Terms**

`Payment within 30 days of invoice; Provider will deliver work by the agreed deadline; Confidentiality must be maintained; Either party may terminate with 15 days notice`

Click **Generate Document**.

Then edit the text and test all three downloads:

- Download TXT
- Download DOCX
- Download PDF

## API example

```powershell
$body = @{
  document_type = "NDA"
  parties = "Alice Smith (Discloser), Example Corp (Recipient)"
  terms = @("Confidentiality for 2 years", "No disclosure to third parties")
  effective_date = "September 30, 2026"
  additional_instructions = "Use clear formal language."
} | ConvertTo-Json

Invoke-RestMethod -Uri http://127.0.0.1:8000/generate -Method Post -ContentType "application/json" -Body $body
```

## Project files

```text
LegalEase/
├── ai_core/
│   ├── __init__.py
│   ├── gemini_generator.py
│   └── mock_generator.py
├── backend/
│   ├── __init__.py
│   ├── config.py
│   ├── main.py
│   ├── routes.py
│   └── schemas.py
├── frontend/
│   ├── __init__.py
│   └── app.py
├── services/
│   ├── __init__.py
│   └── document_service.py
├── assets/
│   └── logo.png
├── tests/
│   ├── __init__.py
│   ├── test_api.py
│   └── test_documents.py
├── .streamlit/config.toml
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── requirements.txt
└── README.md
```

## Docker

Create `.env` first, then:

```bash
docker compose up --build
```

Open:

- Frontend: http://localhost:8501
- Backend: http://localhost:8000/docs

## Security and production notes

- Never commit `.env` or API keys.
- Keep the Gemini API key only on the backend/server side.
- Add authentication before exposing `/generate` publicly.
- Add rate limiting and request quotas for public deployments.
- Consider encrypted storage if document persistence is introduced.
- Review generated documents for jurisdiction-specific requirements.
- For production, pin tested dependency versions and run dependency/security scanning.
