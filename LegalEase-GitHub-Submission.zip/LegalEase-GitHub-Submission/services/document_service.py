from __future__ import annotations
import html
import io
import re
from pathlib import Path
from typing import Iterable
from xml.sax.saxutils import escape

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from fpdf import FPDF

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets'


def sanitize_text(text: str) -> str:
    replacements = {'“': '"', '”': '"', '‘': "'", '’': "'", '–': '-', '—': '-', '•': '-', '\u00a0': ' '}
    for old, new in replacements.items():
        text = text.replace(old, new)
    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text).strip()


def split_sections(text: str) -> list[tuple[str, str]]:
    lines = [line.strip() for line in sanitize_text(text).splitlines()]
    lines = [line for line in lines if line]
    if not lines:
        return []
    sections: list[tuple[str, str]] = []
    heading = lines[0]
    body: list[str] = []
    for line in lines[1:]:
        is_heading = bool(re.match(r'^(?:\d+[.)]\s+|[A-Z][A-Z0-9 &\-/]{3,}$)', line)) and len(line) <= 100
        if is_heading and body:
            sections.append((heading, '\n'.join(body)))
            heading, body = line, []
        elif is_heading and not body:
            heading = line
        else:
            body.append(line)
    sections.append((heading, '\n'.join(body)))
    return sections


def format_html_preview(text: str, doc_type: str) -> str:
    safe = html.escape(sanitize_text(text))
    paragraphs = []
    for block in safe.split('\n\n'):
        if re.match(r'^(?:\d+[.)]\s+)?[A-Z][A-Z0-9 &\-/]{3,}$', block.split('\n')[0]) and len(block.split('\n')[0]) < 100:
            first, *rest = block.split('\n')
            paragraphs.append(f'<h3>{first}</h3>' + ''.join(f'<p>{line}</p>' for line in rest if line))
        else:
            paragraphs.append(''.join(f'<p>{line}</p>' for line in block.split('\n') if line))
    return f'''<div class="legal-preview"><div class="legal-title">{html.escape(doc_type)}</div>{''.join(paragraphs)}</div>'''


def _set_cell_shading(cell, fill='1F2937'):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)


def format_docx(text: str, doc_type: str, terms: Iterable[str] | None = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)

    styles = doc.styles
    styles['Normal'].font.name = 'Times New Roman'
    styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')
    styles['Normal'].font.size = Pt(11)

    logo = ASSETS / 'logo.png'
    if logo.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(logo), width=Inches(1.5))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = 'Times New Roman'
    run.font.size = Pt(16)

    for block in sanitize_text(text).split('\n\n'):
        block = block.strip()
        if not block:
            continue
        lines = block.splitlines()
        first = lines[0].strip()
        if re.match(r'^(?:\d+[.)]\s+)?[A-Z][A-Z0-9 &\-/]{3,}$', first) and len(first) <= 100:
            p = doc.add_paragraph()
            r = p.add_run(first)
            r.bold = True
            r.font.size = Pt(12)
            for line in lines[1:]:
                if line.strip():
                    doc.add_paragraph(line.strip())
        else:
            for line in lines:
                if line.strip():
                    doc.add_paragraph(line.strip())

    clean_terms = [str(t).strip() for t in (terms or []) if str(t).strip()]
    if clean_terms:
        doc.add_paragraph()
        p = doc.add_paragraph()
        r = p.add_run('Requested Terms')
        r.bold = True
        table = doc.add_table(rows=1, cols=2)
        table.style = 'Table Grid'
        hdr = table.rows[0].cells
        hdr[0].text = 'No.'
        hdr[1].text = 'Term'
        for cell in hdr:
            _set_cell_shading(cell)
            for run in cell.paragraphs[0].runs:
                run.font.color.rgb = __import__('docx').shared.RGBColor(255, 255, 255)
                run.bold = True
        for i, term in enumerate(clean_terms, 1):
            cells = table.add_row().cells
            cells[0].text = str(i)
            cells[1].text = term

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run('LegalEase • AI-assisted draft • Review with a qualified legal professional before use').font.size = Pt(8)

    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()


class LegalEasePDF(FPDF):
    def __init__(self, doc_type: str):
        super().__init__()
        self.doc_type = doc_type
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        logo = ASSETS / 'logo.png'
        if logo.exists():
            self.image(str(logo), x=95, y=8, w=20)
            self.ln(14)
        self.set_font('Times', 'B', 12)
        self.cell(0, 7, self.doc_type.upper(), align='C')
        self.ln(8)
        self.set_draw_color(150, 150, 150)
        self.line(12, self.get_y(), 198, self.get_y())
        self.ln(4)

    def footer(self):
        self.set_y(-14)
        self.set_font('Times', '', 8)
        self.cell(0, 5, 'LegalEase - AI-assisted draft - Review before use', align='C')
        self.ln(4)
        self.cell(0, 5, f'Page {self.page_no()}', align='C')


def format_pdf(text: str, doc_type: str) -> bytes:
    pdf = LegalEasePDF(doc_type)
    pdf.set_margins(16, 24, 16)
    pdf.add_page()
    pdf.set_font('Times', '', 11)
    for block in sanitize_text(text).split('\n\n'):
        block = block.strip()
        if not block:
            continue
        lines = block.splitlines()
        first = lines[0].strip()
        if re.match(r'^(?:\d+[.)]\s+)?[A-Z][A-Z0-9 &\-/]{3,}$', first) and len(first) <= 100:
            pdf.set_font('Times', 'B', 12)
            pdf.multi_cell(pdf.epw, 6, first)
            pdf.set_font('Times', '', 11)
            for line in lines[1:]:
                if line.strip():
                    pdf.multi_cell(pdf.epw, 5.5, line.strip())
        else:
            for line in lines:
                if line.strip():
                    pdf.multi_cell(pdf.epw, 5.5, line.strip())
        pdf.ln(2)
    return bytes(pdf.output())
